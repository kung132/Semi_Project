package com.kh.notice.model.service;

public class NoticeService {

}
